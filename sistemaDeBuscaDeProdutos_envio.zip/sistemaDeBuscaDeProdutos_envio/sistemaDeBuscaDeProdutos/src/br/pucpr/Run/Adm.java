package br.pucpr.Run;

import br.pucpr.Administrador;

public class Adm {

    public static void main(String[] args) throws Exception {

        new Administrador().comunicacaoServidor();

    }

}
