package br.pucpr.Run;

import br.pucpr.Servidor.Servidor;

public class Server {

    public static void main(String[] args) throws Exception {

        new Servidor().comunicacao();

    }

}
