package br.pucpr.Run;

import br.pucpr.Clientes.Consumidor;

public class Cliente02 {

    public static void main(String[] args) throws Exception {

        new Consumidor().comunicacaoServidor();

    }

}
